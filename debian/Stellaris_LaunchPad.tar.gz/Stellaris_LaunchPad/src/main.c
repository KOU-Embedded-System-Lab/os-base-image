#include "inc/lm4f120h5qr.h"

int main(void) {
    volatile unsigned long delay;

	// PORTF'yi aktiflestir
    SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOF;
    delay = SYSCTL_RCGC2_R; // zaman gecirmek icin yukarida degistirdigimiz registeri okuyoruz

	// PORTF'nin 3. pinini cikis olarak ayarliyoruz
    GPIO_PORTF_DIR_R |= 0b00000100;

	// PORTF'nin 3. pinini aktiflestiriyoruz
    GPIO_PORTF_DEN_R |= 0b00000100;

    while(1) {

		// Mavi LED'i yak (PortF 2. bite 1 ver)
        GPIO_PORTF_DATA_R |= 0b00000100;

        for(delay = 0; delay < 400000; delay++)
			/* bos dongu ile bekle */;

		// Mavi LED'i sondur (PortF 2. bite 0 ver)
        GPIO_PORTF_DATA_R &= ~(0b00000100);

        for(delay = 0; delay < 400000; delay++)
			/* bos dongu ile bekle */;
    }
}
